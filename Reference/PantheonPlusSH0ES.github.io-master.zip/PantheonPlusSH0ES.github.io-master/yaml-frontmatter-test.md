---
layout: default
tags: yaml-test
categories: yaml-category
date: 2018-01-01 00:00:00 +0000
---
## Yaml Frontmatter Test

Yaml Frontmatter can be used. This page has this yaml frontmatter set at top of page:

  ```
  ---
  layout: default
  tags: yaml-test
  categories: yaml-category
  date: 2018-01-01 00:00:00 +0000
  ---


UQCMF_Pantheon_SH0ES_Project

Instructions:
1. Run codes/MCMC_subsample_UQCMF.py to perform the fit.
2. Run codes/plot_corner_simulated.py to generate plots.
3. View outputs/ for parameter summaries and plots.
4. The latex/ folder is ready for Overleaf upload.

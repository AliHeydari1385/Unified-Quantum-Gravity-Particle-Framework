UQGPF PRD-safe Overleaf package

1. Upload all files/folders to Overleaf.
2. Set main document to uqgpf_prd_safe.tex.
3. Compiler: pdfLaTeX.
4. Figures are in figures/ subfolder.
5. Bibliography via uqgpf_refs.bib.

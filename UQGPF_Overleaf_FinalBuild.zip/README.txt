Overleaf-ready UQGPF project with an undergraduate-friendly introduction added.
Upload this ZIP to Overleaf, ensure graphicx and amsmath packages are enabled.
Figures are in figures/. Bibliography in references.bib.

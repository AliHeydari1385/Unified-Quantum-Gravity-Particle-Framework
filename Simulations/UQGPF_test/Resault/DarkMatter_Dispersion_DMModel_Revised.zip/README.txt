Dark Matter Dispersion – Revised Model
This archive contains the revised LaTeX paper and all related figures.
Figures are located in the figures/ directory and include fits, corner plots, and chi-squared distributions.
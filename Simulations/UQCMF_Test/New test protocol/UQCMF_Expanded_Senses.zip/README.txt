UQCMF_Expanded_Senses Overleaf Project

Structure:
├── main.tex
├── images/
│   └── placeholder.tex
├── bibliography/
│   └── references.bib
└── supplementary/
    └── simulation_code.tex

Ready for Overleaf upload and compilation.

Real-data SI build (GOES/Kp/Pantheon)
Seed=42; includes 5.12σ burst analysis.